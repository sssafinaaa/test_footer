from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from webdriver_manager.chrome import ChromeDriverManager

PAGES = [
    "https://only.digital/",
    "https://only.digital/about",
    "https://only.digital/portfolio",
    "https://only.digital/services",
    "https://only.digital/contacts"
]

def test_footer_elements(driver, url):
    driver.get(url)
    print(f"Проверка страницы: {url}")

    footer = driver.find_element(By.TAG_NAME, "footer")
    assert footer.is_displayed(), "Футер отсутствует"

    logo = footer.find_element(By.CSS_SELECTOR, "img")
    assert logo.is_displayed(), "Логотип в футере отсутствует"

    social_links = footer.find_elements(By.CSS_SELECTOR, "a[href*='instagram'], a[href*='vk'], a[href*='telegram']")
    assert len(social_links) > 0, "Ссылки на соцсети отсутствуют"

    contacts = footer.text
    assert "hello@only.digital" in contacts or "+7" in contacts, "Контактная информация отсутствует"

    print("✓ Проверка пройдена\n")

if __name__ == "__main__":
    driver = webdriver.Chrome(service=Service(ChromeDriverManager().install()))
    driver.maximize_window()
    
    try:
        for page in PAGES:
            test_footer_elements(driver, page)
    finally:
        driver.quit()

