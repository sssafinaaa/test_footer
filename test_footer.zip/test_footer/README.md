# ONLY.DIGITAL Footer Test

Автотест для проверки футера и его элементов на страницах сайта [https://only.digital](https://only.digital).

## Что проверяет скрипт

- Наличие футера
- Наличие логотипа в футере
- Наличие ссылок на соцсети (Instagram, VK, Telegram)
- Наличие контактной информации (email или телефон)

## Установка

```bash
git clone https://github.com/yourusername/only-digital-footer-test.git
cd only-digital-footer-test
pip install -r requirements.txt
